PERFOMANCE MODES v1.0 - AUTO SAVE + SAFETY BACKUP
==================================

MENU LAYOUT
-----------
MAIN
  Current Profile
  Battery Mode
  Performance Mode

INITIAL SETUP
  Save App Profile -> Battery
  Save App Profile -> Performance
  Save Horizon Profile -> Battery
  Save Horizon Profile -> Performance
  Reset Battery App Profiles -> STOCK
  Mark Current Boot -> Battery
  Mark Current Boot -> Performance
  Create Safety Backup
  Restore Safety Backup
  Check Files

Ultrahand officially supports two package pages/tabs, so Initial Setup is the
second page. Switch between Main and Initial Setup with D-Pad left/right.

WHAT "APP PROFILE" MEANS
------------------------
The full:
  /config/horizon-oc/config.ini

is stored as:
  ./Battery/config.ini
or:
  ./Performance/config.ini

Because the full file is copied, all current and future Title-ID game profiles
are captured automatically.

WHAT "HORIZON PROFILE" MEANS
----------------------------
The active:
  /atmosphere/kips/hoc.kip

is stored as:
  ./Battery/hoc.kip
or:
  ./Performance/hoc.kip

AUTO-SAVE ON EVERY MODE SWITCH
------------------------------
When leaving PERFORMANCE:
  live Horizon config -> Performance/config.ini
  live hoc.kip        -> Performance/hoc.kip

Then Battery config + KIP are loaded and the console reboots.

When leaving BATTERY the exact reverse happens.

So after initial setup you do NOT need to manually save changes before
switching. Changes to both the Horizon config/app profiles and hoc.kip are
automatically written back to the profile being left.

RESET BATTERY APP PROFILES
--------------------------
The proven reset routine keeps Battery's [values] section but removes all
per-title game sections. This means Battery games return to stock/default
app clocks.

It only runs while Current Profile = PERFORMANCE, so the active Battery config
cannot accidentally be reset while Battery is the running profile.

UPDATING FROM EARLIER TEST BUILDS
------------------
This ZIP intentionally does NOT include the package-local config.ini. Therefore
copying v1.0 over an earlier test build preserves the existing Current Profile state.

For a fresh install, opening the package initializes Current Profile to UNSET.
Then use one of the two Mark Current Boot entries.

RECOVERY
--------
The separate Hekate safe/no-OC boot entry is not modified.


SAFETY BACKUP
-------------
"Create Safety Backup" stores one complete recovery snapshot under:

  ./Backup/

It contains:
  Active/config.ini
  Active/hoc.kip
  Battery/config.ini
  Battery/hoc.kip
  Performance/config.ini
  Performance/hoc.kip
  package_state.ini

The backup is only replaced when YOU manually run "Create Safety Backup".

"Restore Safety Backup" restores all available files from that snapshot and
then reboots CFW.

Recommended:
Create a Safety Backup once both Battery and Performance profiles are known-good,
and again only after you are happy with later tuning changes.
